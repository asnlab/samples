#include "MyHTTP.h"
#include "GetRequest.h"
#include <iostream>
#include <iomanip>

using namespace std;
using namespace asnrt;
using namespace myhttp;

int main(void) {
   AsnBuffer* buffer = alloc_buffer(1024, true, BASIC_ENCODING_RULES);
   GetRequest* getRequest = new GetRequest();
   getRequest->header_only = true;
   getRequest->lock = false;
   getRequest->accept_types.standards = new bitstring();
   getRequest->accept_types.standards->push_back(true);
   getRequest->accept_types.standards->push_back(true);
   getRequest->accept_types.standards->push_back(false);
   getRequest->accept_types.standards->push_back(false);
   getRequest->accept_types.others = NULL;
   getRequest->url = "www.asnlab.org";
   getRequest->timestamp.fromUTCTime(2012, 12, 21, 12, 12, 21, 0);

   encode_object(buffer, getRequest, GetRequest::TYPE, &GetRequest::CONVERTER);
   octetstring octets;
   buffer_content(buffer, &octets);
   for(unsigned long i=0; i<octets.length(); i++) {
      cout<<setfill('0')<<setw(2)<<hex<<uppercase<<(0xFF & octets.at(i))<<" ";
   }
   cout<<endl;

   delete getRequest;
   free_buffer(buffer);

   MyHTTP::release();

   return 0;
}
