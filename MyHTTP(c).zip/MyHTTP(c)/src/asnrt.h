/*
 * @(#)asnrt.h
 *
 * Copyright (c) 2009-2010, Shannon Information Co., Ltd.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 	1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 *
 * 	2. Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 *
 * 	3. Neither the name of Shannon Information nor the names of its contributors
 * may be used to endorse or promote products derived from this software
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE REGENTS OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
#ifndef ASNRT_H_
#define ASNRT_H_

#include "stdlib.h"
#include "setjmp.h"
#include "string.h"

#ifdef __cplusplus
extern "C" {
#endif

#define		ASNRT_VERSION		"v3.14.15.r20120220"

/* C values types for ASN.1 values */

#ifdef _WIN32
typedef __int64 int64_t;
typedef unsigned __int64 uint64_t;
#else
typedef long long int64_t;
typedef unsigned long long uint64_t;
#endif

#define	false	0
#define	true	1

typedef unsigned char boolean;

typedef struct {
    unsigned int length; /* number of bits */
    char*  bytes;
} Bits;

typedef struct {
    unsigned int length; /* number of bytes */
    char*  bytes;
} Octets;

typedef struct {
    unsigned int length;
    unsigned int* ids;
} Oid;

typedef unsigned short wchar;

typedef unsigned int uchar;

typedef struct {
    signed int year; /* 0~9999 */
    signed char month; /* Jun = 1, ..., Dec = 12 */
    signed char day; /* 1~31 */
    signed char hour; /* 0~23 */
    signed char minute; /* 0~59 */
    signed char second; /* 0~59 */
    signed char hour_offset; /* hour offset from UTC. For example, hour_offset=8 means eight hours ahead of GMT */
    signed char minute_offset;/* minute offset from UTC. For example, minute_offset=15 means 15 minutes ahead of GMT */
    signed int millisec; /* 0~999 */
} Time;

#define List(E)				\
struct {					\
	unsigned int capacity;	\
	unsigned int size;		\
	E* elements;			\
}

Bits* wrapBits(char* bytes, unsigned int length);
Octets* wrapOctets(char* bytes, unsigned int length);

boolean isBitSet(Bits* bits, unsigned int bit);
void setBit(Bits* bits, unsigned int bit);
void clearBit(Bits* bits, unsigned int bit);

unsigned int cstrlen(char* s);
unsigned int wstrlen(wchar* s);
unsigned int ustrlen(uchar* s);


/* The encoding rules */

#define		BASIC_ENCODING_RULES             0
#define		CANONICAL_ENCODING_RULES         1
#define		DISTINGUISHED_ENCODING_RULES     2
#define		UNALIGNED_PACKED_ENCODING_RULES  3
#define		ALIGNED_PACKED_ENCODING_RULES    4

/* The metadata type */

struct AsnCodec;

typedef struct {
	struct AsnCodec* codec;
	void*  config;
} AsnType;

typedef struct TraceStack {
	void* object;
	AsnType* type;
	struct TraceStack* next;
} TraceStack;

/* The buffer context */

typedef	struct {
	jmp_buf	jumper;
	char* file_name;
	int line_number;
	unsigned long position;
	int extval;
	void* trace;
	TraceStack stack;
} AsnContext;

struct AsnInputStream;
struct AsnOutputStream;

/* The working buffer */
typedef struct {
	struct AsnInputStream* in;
	struct AsnOutputStream* out;
	char* array;
	unsigned long position;
	unsigned long capacity;
	unsigned long limit;
	boolean auto_expand;
	char encoding_rules;
	boolean align;
	AsnContext context;
} AsnBuffer;


// Memory Management

/**
 * Allocates a block (nitems * size) bytes and clears it to 0.
 * 
 * Override this function to provide your own allocation function.
 */
extern void* asn_alloc(size_t nitems, size_t size);

/**
 * Deallocates a memory block allocated by a previous call to asn_alloc().
 * 
 * Override this function to provide your own deallocation function.
 */
extern void asn_free(void* block);

/**
 * Copies a block of n bytes from src to dest.
 * 
 * Override this function to provide your own memory copy function.
 */
extern void* asn_memcpy(void* dest, const void* src, size_t n);

/**
 * Compares the first n bytes of the blocks s1 and s2 as unsigned chars.
 * 
 * Override this function to provide your own memory compare function.
 */
extern int asn_memcmp(const void* s1, const void* s2, size_t n);

/**
 * Performs a binary search for the value key in a table (array) of nelem elements in memory.
 * Parameters:
 * 		key - The item to be searched for (the search key)
 *		base - The base (0th element) of the search table
 *		nelem - The number of entries in the table
 *		width - The number of bytes in each entry
 *		fcmp - A user-defined comparison routine that compares two items and returns a value based on the comparison
 * Return: The address of the first entry in the table that matches the search key on success; 0 (No match) on failure.
 * 
 * Override this function to provide your own bsearch function.
 */
extern void* asn_bsearch(const void* key, const void* base, size_t nelem, size_t width, int (*fcmp)(const void*, const void*));


// I/O Manipulation

/** 
 * Callback routine: Reads up to <code>len</code> bytes of data from the input stream into
 * an array of bytes.  An attempt is made to read as many as <code>len</code> bytes, but a
 * smaller number may be read. The number of bytes actually read is returned as an integer.
 *
 * @param    in     the input stream from which to read data.
 * @param    buf    the buffer into which the data is read.
 * @param    len    the maximum number of bytes to read.
 * @return 
 * 			 the total number of bytes read into the buffer, or
 * 			 <code>-1</code> if there is no more data because the end of
 * 			 the stream has been reached.
 **/
typedef int (*AsnReadBytes)(struct AsnInputStream* in, char* buf, int len);

/** 
 * Callback routine: Writes <code>len</code> bytes from the specified byte array
 * to this output stream.
 * @param    buf   the data.
 * @param    len   the number of bytes to write.
 * @return
 * 			 the total number of bytes written, -1 on failure
 **/
typedef int (*AsnWriteBytes)(struct AsnOutputStream* out, char* buf, int len);

/**
 * Flushes this output stream and forces any buffered output bytes
 * to be written out.
 **/
typedef void (*AsnFlushStream)(struct AsnOutputStream* out);

/* The input stream */
typedef struct AsnInputStream {
	void* fd;	/* file descriptor  */
	AsnReadBytes read;
} AsnInputStream;

/* The output stream */
typedef struct AsnOutputStream {
	void* fd;	/* file descriptor  */
	AsnWriteBytes write;
	AsnFlushStream flush;
} AsnOutputStream;

struct AsnPrinter;

/** 
 * Call Back routine: print anything
 **/
typedef int (*AsnPrint)(struct AsnPrinter* printer, const char *__format, ...);

/* the printer */
typedef struct AsnPrinter {
	void* fd;	 		/* file descriptor  */
	AsnPrint print;	 	/* the print call back  */
	AsnContext context; /* reserved for internal use  */
} AsnPrinter;

// Buffer Allocation

/**
 * Wraps an array into a buffer.
 * 
 * The new buffer will be backed by the given byte array;
 * that is, modifications to the buffer will cause the array to be modified and vice versa.  
 * For Basic Encoding Rules, the new buffer's capacity and limit will be <tt>numBytes</tt>, 
 * and for Pack Encoding Rules, the new buffer's capacity and limit will be <tt>numBytes*8</tt>.
 */
AsnBuffer* wrap_buffer(char* array, unsigned long numBytes, char encodingRules);

/**
 * Allocates a new buffer.
 *
 * For Basic Encoding Rules, the new buffer's capacity and limit will be <tt>numBytes</tt>,
 * and for Pack Encoding Rules, the new buffer's capacity and limit will be <tt>numBytes*8</tt>.
 */
AsnBuffer* alloc_buffer(unsigned long numBytes, boolean autoExpand, char encodingRules);

/**
 * Create a new buffer with the specific underlying input stream
 **/
AsnBuffer* input_stream_buffer(AsnInputStream* in, unsigned long numBytes, char encodingRules);

/**
 * Create a new buffer with the specific underlying output stream
 **/
AsnBuffer* output_stream_buffer(AsnOutputStream* out, unsigned long numBytes, char encodingRules);

/**
 * Free a buffer. The memory of byte array and the buffer itself will 
 * be freed. 
 * 
 * Caution: if this buffer is create by wrap_buffer(), it must be deallocated by
 * calling asn_free() instead of this routine.
 */
void free_buffer(AsnBuffer* buffer);

// Encoding/Decoding Routines

/** 
 * encode the object with encoding rules specified in the buffer 
 **/
int encode_object(AsnBuffer* buffer, void* object, AsnType* type);

/** 
 * decode the object with encoding rules specified in the buffer 
 **/
int decode_object(AsnBuffer* buffer, void* object, AsnType* type);


// Freeing Routines

/** 
 * free the object content (memory allocated dynamically) 
 **/
void free_object(void* object, AsnType* type);


// Printing Routines

/** 
 * print the object content with printer call back
 **/
void print_object(void* object, AsnType* type, AsnPrinter* printer);


// Error Handling

/* error codes */
#define		INVALID_TAG                     1
#define		INVALID_LENGTH                  2
#define		INVALID_INTEGER                 3
#define		INVALID_ENUM                    4
#define		INVALID_REAL                    5
#define		OUT_OF_MEMORY                   6
#define		INVALID_TIME                    7
#define		MISSING_COMPONENT               8
#define		EXTRA_COMPONENT                 9
#define		INVALID_INDEX                   10
#define		BUFFER_OVERFLOW                 11
#define		BUFFER_UNDERFLOW                12
#define		INVALID_ENCODE_RULE             13
#define		NULL_POINTER_EXCEPTION          14
#define		NOT_PERMITTED_ALPHABET          15
#define		NO_MATCH_INFO_OBJ               16
#define		INVALID_LICENSE                 17
#define		INVALID_SIZE                    18
#define		IO_EXCEPTION                    19

/**
 * print the object content with problem marks
 **/
void print_problem_marks(AsnBuffer* buffer, void* object, AsnType* type, AsnPrinter* printer);



// ~~ Internal API ~~ //

#define PUBLIC
#define PRIVATE static

#ifndef offsetof
#define	offsetof(s, m) (size_t)&( ((s*)0)->m )
#endif

#ifndef msizeof
#define msizeof(s,m) sizeof(((s*)0)->m)
#endif

#ifndef psizeof
#define psizeof(s,m) sizeof(*(((s*)0)->m))
#endif

extern unsigned char FIRST_MASK[];
extern unsigned char SECOND_MASK[];
extern unsigned char SET_MASK[];
extern unsigned char CLEAR_MASK[];
extern char* err_msgs[];

/* license */
extern char sn_key[];
extern int  sn_len;

/* metadata types */

typedef struct {
	int64_t bmin;
	int64_t bmax;
	unsigned int order      :2;
	unsigned int hasBmin    :1;
	unsigned int hasBmax    :1;
	unsigned int numBits    :7;
	unsigned int numOcts    :4;
	unsigned int extensible :1;
} AsnIntegerRange;

typedef struct {
	unsigned int lmin; 
	unsigned int lmax; 
	unsigned int order      :2;
	unsigned int hasLmin    :1;
	unsigned int hasLmax    :1;
	unsigned int numBits    :7;
	unsigned int numOcts    :4;
	unsigned int extensible :1;
} AsnSizeRange;

typedef struct {
	char* permittedAlphabets;
	unsigned int n;
	unsigned int b :6;
	unsigned int B :6;
	unsigned int reindexing :1; 
	unsigned int REINDEXING :1; 
	AsnSizeRange sizeRange;
} AsnMString;

typedef struct {
	wchar* permittedAlphabets;
	unsigned int n;
	unsigned int b :6;
	unsigned int B :6;
	unsigned int reindexing :1; 
	unsigned int REINDEXING :1; 
	AsnSizeRange sizeRange;
} AsnWString;

typedef struct {
	uchar* permittedAlphabets;
	unsigned int n;
	unsigned int b :6;
	unsigned int B :6;
	unsigned int reindexing :1; 
	unsigned int REINDEXING :1; 
	AsnSizeRange sizeRange;
} AsnUString;

typedef struct {
	AsnType* componentType;
	unsigned int componentWidth; 
	AsnSizeRange sizeRange;
} AsnListType;

typedef struct {
	unsigned long tag;
	AsnType* underlyingType;
} AsnTaggedType;

typedef struct {
	char** enumNames;
	int* rootEnumeration; 
	unsigned int numEnums; 
	unsigned int numBits :7; 
	unsigned int numOcts :4; 
	unsigned int width :4;
	unsigned int extensible :1; 
	int* extensionEnumeration; 
	unsigned int numExtensions; 
} AsnEnumerated;

typedef struct {
	char* name;
	AsnType* type;
	unsigned int width;
	boolean cycle;
} AsnAlternative;

typedef struct {
	AsnAlternative* rootAlternatives; 
	unsigned int numAlternatives; 
	unsigned int numBits :7; 
	unsigned int numOcts :4; 
	unsigned int extensible :1; 
	AsnAlternative* extensionAlternatives; 
	unsigned int numExtensions; 
	unsigned int valueOffset;
} AsnChoice;

typedef struct {
	char* name;
	AsnType* type;
	boolean optional;
	void* defval;
	unsigned int offset;
	unsigned int width;
} AsnComponent;

typedef struct {
	AsnComponent* components;
	unsigned int numComponents;
	unsigned int bitmapSize;
} AsnExtensionAddition;

typedef struct {
	AsnComponent* rootComponents;
	unsigned int numComponents;
	unsigned int bitmapSize;
	boolean extensible;
	AsnExtensionAddition* extensionAdditions;
	unsigned int numExtensions;
} AsnComposite;

typedef struct {
	unsigned int fieldOffset;
	unsigned int compomentIndex;
	unsigned int compomentLevel;
} AsnInfoObjIndexer;

typedef struct {
	void* infoObjects;
	unsigned int numInfoObjs;
	unsigned int widthOfInfoObj;
	unsigned int actualTypeOffset;
	AsnInfoObjIndexer* indexers;
	unsigned int numIndexers;
	AsnType* actualType; // exclusive with other fields
} AsnOpenType;

extern char _NUMERIC_STRING_pa_[];

extern AsnType BOOLEAN_TYPE;

extern AsnType NULL_TYPE;

#define INTEGER_TYPE(modifier, name, bmin, bmax, order, hasBmin, hasBmax, numBits, numOcts, extensible)\
	static AsnIntegerRange _##name##_cfg_ = {bmin, bmax, order, hasBmin, hasBmax, numBits, numOcts, extensible};\
	modifier AsnType name = { &INTEGER_CODEC, &_##name##_cfg_  }

#define LONG_TYPE(modifier, name, bmin, bmax, order, hasBmin, hasBmax, numBits, numOcts, extensible)\
	static AsnIntegerRange _##name##_cfg_ = {bmin, bmax, order, hasBmin, hasBmax, numBits, numOcts, extensible};\
	modifier AsnType name = { &LONG_CODEC, &_##name##_cfg_  }

#define INT64_TYPE(modifier, name, bmin, bmax, order, hasBmin, hasBmax, numBits, numOcts, extensible)\
	static AsnIntegerRange _##name##_cfg_ = {bmin, bmax, order, hasBmin, hasBmax, numBits, numOcts, extensible};\
	modifier AsnType name = { &INT64_CODEC, &_##name##_cfg_  }

extern AsnType FLOAT_TYPE;

extern AsnType DOUBLE_TYPE;

#define BITSTRING_TYPE(modifier, name, lmin, lmax, order, hasLmin, hasLmax, numBits, numOcts, extensible)\
	static AsnSizeRange _##name##_cfg_ = {lmin, lmax, order, hasLmin, hasLmax, numBits, numOcts, extensible};\
	modifier AsnType name = { &BITSTRING_CODEC, &_##name##_cfg_  }

#define OCTETSTRING_TYPE(modifier, name, lmin, lmax, order, hasLmin, hasLmax, numBits, numOcts, extensible)\
	static AsnSizeRange _##name##_cfg_ = {lmin, lmax, order, hasLmin, hasLmax, numBits, numOcts, extensible};\
	modifier AsnType name = { &OCTETSTRING_CODEC, &_##name##_cfg_  }

extern AsnType OBJECTIDENTIFIER_TYPE;

extern AsnType RELATIVEOID_TYPE;

#define NUMERICSTRING_TYPE(modifier, name, pa, n, b, B, reindexing, REINDEXING, lmin, lmax, order, hasLmin, hasLmax, numBits, numOcts, extensible)\
	static AsnMString _##name##_cfg_ = { pa, n, b, B, reindexing, REINDEXING, {lmin, lmax, order, hasLmin, hasLmax, numBits, numOcts, extensible} };\
	modifier AsnType name = { &NUMERICSTRING_CODEC, &_##name##_cfg_  }
	
#define PRINTABLESTRING_TYPE(modifier, name, pa, n, b, B, reindexing, REINDEXING, lmin, lmax, order, hasLmin, hasLmax, numBits, numOcts, extensible)\
	static AsnMString _##name##_cfg_ = { pa, n, b, B, reindexing, REINDEXING, {lmin, lmax, order, hasLmin, hasLmax, numBits, numOcts, extensible} };\
	modifier AsnType name = { &PRINTABLESTRING_CODEC, &_##name##_cfg_  }
	
#define VISIBLESTRING_TYPE(modifier, name, pa, n, b, B, reindexing, REINDEXING, lmin, lmax, order, hasLmin, hasLmax, numBits, numOcts, extensible)\
	static AsnMString _##name##_cfg_ = { pa, n, b, B, reindexing, REINDEXING, {lmin, lmax, order, hasLmin, hasLmax, numBits, numOcts, extensible} };\
	modifier AsnType name = { &VISIBLESTRING_CODEC, &_##name##_cfg_  }
	
#define IA5STRING_TYPE(modifier, name, pa, n, b, B, reindexing, REINDEXING, lmin, lmax, order, hasLmin, hasLmax, numBits, numOcts, extensible)\
	static AsnMString _##name##_cfg_ = { pa, n, b, B, reindexing, REINDEXING, {lmin, lmax, order, hasLmin, hasLmax, numBits, numOcts, extensible} };\
	modifier AsnType name = { &IA5STRING_CODEC, &_##name##_cfg_  }

#define BMPSTRING_TYPE(modifier, name, pa, n, b, B, reindexing, REINDEXING, lmin, lmax, order, hasLmin, hasLmax, numBits, numOcts, extensible)\
	static AsnWString _##name##_cfg_ = { pa, n, b, B, reindexing, REINDEXING, {lmin, lmax, order, hasLmin, hasLmax, numBits, numOcts, extensible} };\
	modifier AsnType name = { &BMPSTRING_CODEC, &_##name##_cfg_  }
	
#define UNIVERSALSTRING_TYPE(modifier, name, pa, n, b, B, reindexing, REINDEXING, lmin, lmax, order, hasLmin, hasLmax, numBits, numOcts, extensible)\
	static AsnUString _##name##_cfg_ = { pa, n, b, B, reindexing, REINDEXING, {lmin, lmax, order, hasLmin, hasLmax, numBits, numOcts, extensible} };\
	modifier AsnType name = { &UNIVERSALSTRING_CODEC, _&name##_cfg_  }

extern AsnType TELETEXSTRING_TYPE;

extern AsnType VIDEOTEXSTRING_TYPE;

extern AsnType GRAPHICSTRING_TYPE;

extern AsnType GENERALSTRING_TYPE;

extern AsnType CHARACTERSTRING_TYPE;

extern AsnType UTF8STRING_TYPE;

extern AsnType OBJECTDESCRIPTOR_TYPE;

extern AsnType GENERALIZEDTIME_TYPE;

extern AsnType UTCTIME_TYPE;

#define SEQUENCEOF_TYPE(modifier, name, componentType, componentWidth, lmin, lmax, order, hasLmin, hasLmax, numBits, numOcts, extensible)\
	static AsnListType _##name##_cfg_ = { &componentType, componentWidth, {lmin, lmax, order, hasLmin, hasLmax, numBits, numOcts, extensible} };\
	modifier AsnType name = { &SEQUENCEOF_CODEC, &_##name##_cfg_ }

#define SETOF_TYPE(modifier, name, componentType, componentWidth, lmin, lmax, order, hasLmin, hasLmax, numBits, numOcts, extensible)\
	static AsnListType _##name##_cfg_ = { &componentType, componentWidth, {lmin, lmax, order, hasLmin, hasLmax, numBits, numOcts, extensible} };\
	modifier AsnType name = { &SETOF_CODEC, &_##name##_cfg_ }

#define IMPLICIT_TYPE(modifier, name, tag, underlyingType)\
	static AsnTaggedType _##name##_cfg_ = {  tag, &underlyingType };\
	modifier AsnType name = { &IMPLICIT_CODEC, &_##name##_cfg_ }

#define EXPLICIT_TYPE(modifier, name, tag, underlyingType)\
	static AsnTaggedType _##name##_cfg_ = {  tag, &underlyingType };\
	modifier AsnType name = { &EXPLICIT_CODEC, &_##name##_cfg_ }
	
#define OPEN_TYPE(modifier, name, infoObjects, numInfoObjs, widthOfInfoObj, actualTypeOffset, indexers, numIndexers, actualType)\
	static AsnOpenType _##name##_cfg_ = {  infoObjects, numInfoObjs, widthOfInfoObj,  actualTypeOffset, indexers, numIndexers, actualType };\
	modifier AsnType name = { &OPEN_CODEC, &_##name##_cfg_ }
	
#define DEFAULT_VALUE(name, length, bytes)\
	static Octets name = { length, bytes }
	
/* ASN.1 Codec */

extern struct AsnCodec BOOLEAN_CODEC;

extern struct AsnCodec NULL_CODEC;

extern struct AsnCodec INTEGER_CODEC;

extern struct AsnCodec LONG_CODEC;

extern struct AsnCodec INT64_CODEC;

extern struct AsnCodec ENUMERATED_CODEC;

extern struct AsnCodec FLOAT_CODEC;

extern struct AsnCodec DOUBLE_CODEC;

extern struct AsnCodec BITSTRING_CODEC;

extern struct AsnCodec OCTETSTRING_CODEC;

extern struct AsnCodec OBJECTIDENTIFIER_CODEC;

extern struct AsnCodec RELATIVEOID_CODEC;

extern struct AsnCodec NUMERICSTRING_CODEC;

extern struct AsnCodec PRINTABLESTRING_CODEC;

extern struct AsnCodec VISIBLESTRING_CODEC;

extern struct AsnCodec IA5STRING_CODEC;

extern struct AsnCodec BMPSTRING_CODEC;

extern struct AsnCodec UNIVERSALSTRING_CODEC;

extern struct AsnCodec TELETEXSTRING_CODEC;

extern struct AsnCodec VIDEOTEXSTRING_CODEC;

extern struct AsnCodec GRAPHICSTRING_CODEC;

extern struct AsnCodec GENERALSTRING_CODEC;

extern struct AsnCodec CHARACTERSTRING_CODEC;

extern struct AsnCodec UTF8STRING_CODEC;

extern struct AsnCodec OBJECTDESCRIPTOR_CODEC;

extern struct AsnCodec GENERALIZEDTIME_CODEC;

extern struct AsnCodec UTCTIME_CODEC;

extern struct AsnCodec SEQUENCE_CODEC;

extern struct AsnCodec SET_CODEC;

extern struct AsnCodec CHOICE_CODEC;

extern struct AsnCodec SEQUENCEOF_CODEC;

extern struct AsnCodec SETOF_CODEC;

extern struct AsnCodec IMPLICIT_CODEC;

extern struct AsnCodec EXPLICIT_CODEC;

extern struct AsnCodec OPEN_CODEC;

#ifdef __cplusplus
}
#endif

#endif /*ASNRT_H_*/

