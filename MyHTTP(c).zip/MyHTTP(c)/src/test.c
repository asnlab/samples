#include "stdio.h"
#include "stdlib.h"
#include "stdarg.h"
#include "GetRequest.h"

static int print(AsnPrinter* printer, const char* __format, ...);

AsnPrinter printer = { 0, print };

int main(void) {
   int result;

   char bytes[1] = { 0xC0 };
   Bits standards = { 4, bytes };
   struct GetRequest myRequest = {
      true /* header_only */,
      false /* lock */,
      {
         &standards /* standards */,
         NULL /* others */
      } /* accept_types */,
      "www.asnlab.org" /* url */,
      { 2012, 12, 21, 12, 12, 21, 0, 0, 0 } /* timestamp */
   };

   /*
    * Allocate the memory for the buffer
    */
   AsnBuffer* buffer = alloc_buffer(160, true, BASIC_ENCODING_RULES);

   /*
    * Do the encoding
    */
   result = encode_GetRequest(buffer, &myRequest);

   if(result==0) {
      /*
       * Print out the content of the buffer
       */
      int i;
      for(i=0; i<buffer->limit; i++) {
         char byte = buffer->array[i];
         printf("%02X ", byte & 0xFF);
      }
   }
   else {
      fprintf(stderr, "Error in encoding, error code: %d.\n", result);
      print_problem_marks(buffer, &myRequest, &GETREQUEST_TYPE, &printer);
   }

   /*
    * Deallocate the memory for the buffer
    */
   free_buffer(buffer);

   return 0;
}

static int print(AsnPrinter* printer, const char* __format, ...) {
   va_list arg_ptr;
   int cnt;
   va_start(arg_ptr, __format);
   cnt = vprintf(__format, arg_ptr);
   va_end(arg_ptr);
   return cnt;
}
